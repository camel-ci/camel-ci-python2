name = "camel-ci-python2"
